// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "forge-std/Test.sol";
import "../src/GearTrust.sol";

contract GearTrustTest is Test {
    GearTrust internal gearTrust;
    address internal owner = address(this);
    address internal arbitrator = address(0xA11CE);
    address internal business = address(0xB055);
    address internal renter = address(0xCAFE);
    address internal stranger = address(0xBAD);

    function setUp() public {
        gearTrust = new GearTrust(arbitrator);
        vm.prank(business);
        gearTrust.registerBusiness("Northside Camera Rentals");
    }

    function _issue() internal returns (uint256 id) {
        vm.warp(1_800_000_000);
        vm.prank(business);
        id = gearTrust.issueRentalRecord(
            renter,
            keccak256("camera-001"),
            keccak256("agreement-document"),
            keccak256("return-condition-report"),
            uint64(block.timestamp - 2 days),
            uint64(block.timestamp)
        );
    }

    function testBusinessCanRegisterAndIssueRecord() public {
        uint256 id = _issue();
        GearTrust.RentalRecord memory record = gearTrust.getRentalRecord(id);
        assertEq(record.issuer, business);
        assertEq(record.renter, renter);
        assertEq(uint256(record.status), uint256(GearTrust.RecordStatus.Completed));

        (bool exists, bool issuerRegistered, GearTrust.RecordStatus status) =
            gearTrust.verifyRentalRecord(id);
        assertTrue(exists);
        assertTrue(issuerRegistered);
        assertEq(uint256(status), uint256(GearTrust.RecordStatus.Completed));
    }

    function testUnregisteredAddressCannotIssue() public {
        vm.warp(1_800_000_000);
        vm.prank(stranger);
        vm.expectRevert(GearTrust.NotRegisteredBusiness.selector);
        gearTrust.issueRentalRecord(
            renter, keccak256("equipment"), keccak256("agreement"), bytes32(0),
            uint64(block.timestamp - 1 days), uint64(block.timestamp)
        );
    }

    function testStrangerCannotDispute() public {
        uint256 id = _issue();
        vm.prank(stranger);
        vm.expectRevert(GearTrust.NotRenterOrIssuer.selector);
        gearTrust.raiseDispute(id);
    }

    function testRenterCanRaiseAndArbitratorCanResolve() public {
        uint256 id = _issue();
        vm.prank(renter);
        gearTrust.raiseDispute(id);

        vm.prank(arbitrator);
        gearTrust.resolveDispute(id, true);

        GearTrust.RentalRecord memory record = gearTrust.getRentalRecord(id);
        assertEq(uint256(record.status), uint256(GearTrust.RecordStatus.ResolvedForRenter));
    }

    function testOnlyOwnerCanSuspendBusiness() public {
        vm.prank(stranger);
        vm.expectRevert(GearTrust.NotOwner.selector);
        gearTrust.setBusinessStatus(business, false);

        gearTrust.setBusinessStatus(business, false);
        (bool exists, bool issuerRegistered,) = gearTrust.verifyRentalRecord(999);
        assertFalse(exists);
        assertFalse(issuerRegistered);
    }

    function testSuspendedIssuerCannotIssueNewRecords() public {
        gearTrust.setBusinessStatus(business, false);
        vm.warp(1_800_000_000);
        vm.prank(business);
        vm.expectRevert(GearTrust.NotRegisteredBusiness.selector);
        gearTrust.issueRentalRecord(
            renter, keccak256("equipment"), keccak256("agreement"), bytes32(0),
            uint64(block.timestamp - 1 days), uint64(block.timestamp)
        );
    }

    function testCannotIssueWithInvalidDates() public {
        vm.warp(1_800_000_000);
        vm.prank(business);
        vm.expectRevert(GearTrust.InvalidRentalData.selector);
        gearTrust.issueRentalRecord(
            renter, keccak256("equipment"), keccak256("agreement"), bytes32(0),
            uint64(block.timestamp), uint64(block.timestamp - 1)
        );
    }
}
