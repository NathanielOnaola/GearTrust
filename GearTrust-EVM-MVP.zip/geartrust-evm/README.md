# GearTrust — EVM smart-contract MVP

GearTrust is a prototype registry for portable equipment-rental records. Participating rental businesses register as issuers, issue a signed-by-wallet onchain record when a rental is completed, and another business can verify the record's issuer and current status using its ID.

This is a demonstration MVP, not an audited production system.

## What is included

- `src/GearTrust.sol` — business registry, rental-record issuance, verification, dispute flagging and arbitrator-recorded outcomes.
- `test/GearTrust.t.sol` — Foundry tests for registration, issuance, verification, access control and disputes.
- `script/Deploy.s.sol` — deployment script.
- `web/index.html` — small browser interface using MetaMask and ethers v6.

## Important design and trust boundaries

- A rental record is only as truthful as the business that issues it. Blockchain proves that a particular wallet issued a particular record and that its onchain fields have not been silently changed; it does **not** prove the equipment's physical condition or the truth of an inspection.
- A registered issuer can issue records for rentals it claims were completed. The contract does not independently verify invoices, signatures on offchain agreements, payment, handover or return.
- Disputes are flagged by the renter or issuer. A separately configured arbitrator records the outcome. The arbitrator's decision is an administrative attestation, not an objective determination made by the blockchain.
- The owner can suspend issuers and change the arbitrator. For a real deployment, put owner and arbitrator roles behind a multisig and publish transparent issuer admission, suspension and appeal policies.
- Public blockchains are public. A renter wallet can be linked to a real person. Use a wallet chosen for this purpose and do not put names, phone numbers, identity documents, addresses, images or raw rental documents onchain.
- The hashes are commitments to offchain files. The app does not upload, store or retrieve those files.
- The contract does not escrow deposits. Escrow is deliberately excluded from this first MVP because safe deposit handling needs explicit cancellation, late-return, partial-refund, timeout and dispute rules. Adding a simplistic escrow would create avoidable financial risk.

## Requirements

- Foundry (`forge` and `cast`)
- A wallet such as MetaMask
- An RPC endpoint for the EVM test network you intend to use
- Test ETH on that network for deployment and transactions

## Install and test

```bash
forge install foundry-rs/forge-std --no-commit
forge build
forge test -vv
```

The tests run locally and do not require a funded wallet or RPC endpoint.

## Configure deployment

1. Copy `.env.example` to `.env`.
2. Set `PRIVATE_KEY` to a dedicated test wallet's private key. Never use a wallet holding valuable assets.
3. Set `ARBITRATOR_ADDRESS` to a separate trusted test wallet address.
4. Set `RPC_URL` to the RPC endpoint for your chosen EVM testnet.
5. Keep `.env` private and do not commit it.

Load the environment variables into your shell:

```bash
source .env
```

Deploy (example uses Sepolia; change the chain/RPC to the network you choose):

```bash
forge script script/Deploy.s.sol:DeployGearTrust \
  --rpc-url "$RPC_URL" \
  --broadcast \
  -vvvv
```

The deployment output includes the contract address. Save it; the browser app needs it.

Optional verification, if the selected explorer is supported by Foundry:

```bash
forge verify-contract \
  --chain sepolia \
  --compiler-version 0.8.24 \
  YOUR_DEPLOYED_CONTRACT_ADDRESS \
  src/GearTrust.sol:GearTrust \
  --constructor-args $(cast abi-encode "constructor(address)" "$ARBITRATOR_ADDRESS")
```

## Run the browser interface

The interface is a static HTML file. It uses the ethers v6 browser CDN and MetaMask.

1. Open `web/index.html` in a browser, or serve the project directory locally:

```bash
python3 -m http.server 8000
```

2. Visit `http://localhost:8000/web/`.
3. Connect MetaMask and switch it to the same network where the contract is deployed.
4. Paste the deployed contract address into the app and select **Save address**.
5. Register a business from the wallet that will act as the rental business.
6. Issue a record from that registered business wallet.
7. Copy the record ID and use **Verify record** from another wallet/business.

The interface includes a short warning that records and wallet addresses are public. The demo creates hashes in the browser from the entered reference strings; in a production app, hash canonicalized files/documents and store the actual files securely offchain.

## Contract workflow

1. A business wallet calls `registerBusiness(displayName)`.
2. A registered business calls `issueRentalRecord(...)`.
3. A renter shares the record ID with another business.
4. The receiving business calls `verifyRentalRecord(recordId)` and `getRentalRecord(recordId)`.
5. The renter or issuer may call `raiseDispute(recordId)`.
6. The configured arbitrator calls `resolveDispute(recordId, inRenterFavor)`.

Record status values:
- `0` — Completed
- `1` — Disputed
- `2` — ResolvedForRenter
- `3` — ResolvedForBusiness

## Before production

This MVP needs a professional security review before handling real deposits or valuable business records. Further work should include: a multisig-controlled issuer registry, issuer onboarding and revocation policy, appeal/correction flow, signed offchain evidence, privacy-preserving credentials, rate limits/anti-spam, event indexing, formal tests and a reviewed escrow design.
