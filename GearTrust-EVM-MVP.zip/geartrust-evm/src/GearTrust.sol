// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// @title GearTrust
/// @notice Minimal onchain registry for portable, verifiable equipment-rental records.
/// @dev Do not put names, phone numbers, IDs, photos, inspection reports, or other personal
///      information onchain. Hashes are commitments to offchain documents, not proof that
///      the underlying statements are true.
contract GearTrust {
    address public owner;
    address public arbitrator;
    uint256 public nextRecordId = 1;

    enum RecordStatus {
        Completed,
        Disputed,
        ResolvedForRenter,
        ResolvedForBusiness
    }

    struct Business {
        bool registered;
        string displayName; // Use a non-sensitive business label; can also be a name hash.
        uint64 registeredAt;
    }

    struct RentalRecord {
        address issuer;
        address renter; // A wallet address; publicly visible and potentially linkable.
        bytes32 equipmentRef; // Hash/reference to an offchain equipment description.
        bytes32 agreementHash; // Hash of the signed offchain rental agreement.
        bytes32 conditionHash; // Hash of offchain return/inspection evidence, if any.
        uint64 startedAt;
        uint64 completedAt;
        RecordStatus status;
        uint64 issuedAt;
    }

    mapping(address => Business) public businesses;
    mapping(uint256 => RentalRecord) private records;

    event BusinessRegistered(address indexed business, string displayName);
    event BusinessUpdated(address indexed business, string displayName);
    event BusinessStatusChanged(address indexed business, bool registered);
    event ArbitratorChanged(address indexed previousArbitrator, address indexed newArbitrator);
    event RentalRecordIssued(
        uint256 indexed recordId,
        address indexed issuer,
        address indexed renter,
        bytes32 equipmentRef,
        bytes32 agreementHash
    );
    event RentalDisputed(uint256 indexed recordId, address indexed raisedBy);
    event DisputeResolved(uint256 indexed recordId, RecordStatus outcome);

    error NotOwner();
    error NotRegisteredBusiness();
    error AlreadyRegistered();
    error InvalidAddress();
    error InvalidRentalData();
    error RecordNotFound();
    error NotRenterOrIssuer();
    error NotArbitrator();
    error RecordNotDisputable();
    error RecordNotDisputed();

    modifier onlyOwner() {
        if (msg.sender != owner) revert NotOwner();
        _;
    }

    modifier onlyRegisteredBusiness() {
        if (!businesses[msg.sender].registered) revert NotRegisteredBusiness();
        _;
    }

    constructor(address initialArbitrator) {
        if (initialArbitrator == address(0)) revert InvalidAddress();
        owner = msg.sender;
        arbitrator = initialArbitrator;
        emit ArbitratorChanged(address(0), initialArbitrator);
    }

    function registerBusiness(string calldata displayName) external {
        if (businesses[msg.sender].registered) revert AlreadyRegistered();
        if (bytes(displayName).length == 0) revert InvalidRentalData();
        businesses[msg.sender] = Business({
            registered: true,
            displayName: displayName,
            registeredAt: uint64(block.timestamp)
        });
        emit BusinessRegistered(msg.sender, displayName);
    }

    function updateBusinessName(string calldata displayName) external {
        if (!businesses[msg.sender].registered) revert NotRegisteredBusiness();
        if (bytes(displayName).length == 0) revert InvalidRentalData();
        businesses[msg.sender].displayName = displayName;
        emit BusinessUpdated(msg.sender, displayName);
    }

    /// @notice Owner can suspend a registered issuer. Existing records remain queryable.
    function setBusinessStatus(address business, bool isRegistered) external onlyOwner {
        if (business == address(0)) revert InvalidAddress();
        if (bytes(businesses[business].displayName).length == 0) revert NotRegisteredBusiness();
        businesses[business].registered = isRegistered;
        emit BusinessStatusChanged(business, isRegistered);
    }

    function setArbitrator(address newArbitrator) external onlyOwner {
        if (newArbitrator == address(0)) revert InvalidAddress();
        address previous = arbitrator;
        arbitrator = newArbitrator;
        emit ArbitratorChanged(previous, newArbitrator);
    }

    /// @notice A registered rental business issues a completed-rental record.
    /// @param renter Wallet address chosen by the renter. Public onchain data can be linked.
    /// @param equipmentRef Hash of an offchain equipment reference/description.
    /// @param agreementHash Hash of the rental agreement stored offchain.
    /// @param conditionHash Hash of offchain return/inspection evidence; bytes32(0) if absent.
    function issueRentalRecord(
        address renter,
        bytes32 equipmentRef,
        bytes32 agreementHash,
        bytes32 conditionHash,
        uint64 startedAt,
        uint64 completedAt
    ) external onlyRegisteredBusiness returns (uint256 recordId) {
        if (renter == address(0) || equipmentRef == bytes32(0) || agreementHash == bytes32(0)) {
            revert InvalidRentalData();
        }
        if (startedAt == 0 || completedAt < startedAt || completedAt > block.timestamp) {
            revert InvalidRentalData();
        }

        recordId = nextRecordId++;
        records[recordId] = RentalRecord({
            issuer: msg.sender,
            renter: renter,
            equipmentRef: equipmentRef,
            agreementHash: agreementHash,
            conditionHash: conditionHash,
            startedAt: startedAt,
            completedAt: completedAt,
            status: RecordStatus.Completed,
            issuedAt: uint64(block.timestamp)
        });

        emit RentalRecordIssued(recordId, msg.sender, renter, equipmentRef, agreementHash);
    }

    /// @notice Renter or issuing business may flag a completed record for review.
    function raiseDispute(uint256 recordId) external {
        RentalRecord storage record = records[recordId];
        if (record.issuer == address(0)) revert RecordNotFound();
        if (msg.sender != record.renter && msg.sender != record.issuer) revert NotRenterOrIssuer();
        if (record.status != RecordStatus.Completed) revert RecordNotDisputable();

        record.status = RecordStatus.Disputed;
        emit RentalDisputed(recordId, msg.sender);
    }

    /// @notice A separately designated arbitrator records an outcome; it does not establish facts.
    function resolveDispute(uint256 recordId, bool inRenterFavor) external {
        if (msg.sender != arbitrator) revert NotArbitrator();
        RentalRecord storage record = records[recordId];
        if (record.issuer == address(0)) revert RecordNotFound();
        if (record.status != RecordStatus.Disputed) revert RecordNotDisputed();

        RecordStatus outcome = inRenterFavor
            ? RecordStatus.ResolvedForRenter
            : RecordStatus.ResolvedForBusiness;
        record.status = outcome;
        emit DisputeResolved(recordId, outcome);
    }

    function getRentalRecord(uint256 recordId) external view returns (RentalRecord memory) {
        RentalRecord memory record = records[recordId];
        if (record.issuer == address(0)) revert RecordNotFound();
        return record;
    }

    /// @notice Verification checks record existence, current issuer registration, and status.
    ///         A consumer should also inspect the full record and dispute outcome.
    function verifyRentalRecord(uint256 recordId)
        external
        view
        returns (bool exists, bool issuerCurrentlyRegistered, RecordStatus status)
    {
        RentalRecord memory record = records[recordId];
        if (record.issuer == address(0)) return (false, false, RecordStatus.Completed);
        return (true, businesses[record.issuer].registered, record.status);
    }

    function transferOwnership(address newOwner) external onlyOwner {
        if (newOwner == address(0)) revert InvalidAddress();
        owner = newOwner;
    }
}
