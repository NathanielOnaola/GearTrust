// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import "forge-std/Script.sol";
import "../src/GearTrust.sol";

contract DeployGearTrust is Script {
    function run() external returns (GearTrust deployed) {
        uint256 deployerKey = vm.envUint("PRIVATE_KEY");
        address arbitrator = vm.envAddress("ARBITRATOR_ADDRESS");

        vm.startBroadcast(deployerKey);
        deployed = new GearTrust(arbitrator);
        vm.stopBroadcast();
    }
}
